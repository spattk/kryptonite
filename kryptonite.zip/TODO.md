#To Do 

## TOP PRIORITY TASKS
 - [ ] Image resizing
 - [x] Gallery module
 - [x] Profiling
 - [x] Discuss the fortnight report thing on the forum
 - [x] Discuss the profiling to the team and others.

##FRONT-END DESIGN

###New features to design

- [x] Fortnight Report Layout and Wireframing
- [ ] Add Pagination to the profiling of student in each sectors page
- [ ] Add styling to team members that one (dont remember the name )
- [ ] Design Gallery Page

###Features to be updated

- [ ] when you are not logged in and try to open some admin page, you are redirected to login page and after login it should be redirected to the requested page (which is now set to default as dashboard) using $_SERVER['HTTP_HOST'] & $_SERVER['REQUEST_URI'].
- [ ] Add routing to sector/index/sector-2 to sector/sector-2
- [ ] Make people speak image dynamic
- [ ] Make the working of contact us mail service
- [ ] Add contents to Archives page
- [ ] Make the blog link dynamic on the Nav-Bar
- [ ] Check the resizing of image (blueimp/blue sth upload plugin )
- [ ] Link all the social networking option available on the bottom of the page
- [ ] Remove the black side of Bootstrap Carousel
- [ ] Align about us according to it is stored in database ( "pre" tag not looking good )
- [ ] Add Top 3 images and quotes
- [ ] Add Sector images
- [ ] Add Project images
- [ ] Add team images
- [ ] Add people images

###Important Fixes

##BACK-END (ADMIN-PANEL)

###New features to design

- [ ] Design back-end (insert function with JSON implementations) for gallery and student profiling. 
- [ ] Add caching system
- [x] Add trash feature to every section
- [ ] In the edit post page, show the image using "img" tag and there should be remove image and after removal of the image "input" for new image to be shown (not prior to that). 
###Features to be updated

- [ ] Make a deleted global variable to show that one of the post from the browse has been deleted (It's implemented now with the use of a parameter in the browse function , change it to without parameter)
- [x] On clicking delete show confirm delete alert
- [x] Add transition to the edit and delete of Admin Panel
- [x] Add delete functionality to every section
- [ ] Make the user detail who logged in dynamic instead of Sitesh
- [x] Change the link of left side AASRA to point to dashboard
- [x] Change the fa-icons on the left of each section

###Important Fixes

##BACK-END (DATABASE)

###New features to design

###Features to be updated

###Important Fixes
