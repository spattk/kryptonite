<!-- Footer -->
<footer class="text-center site-footer">
        <div class="footer-below">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        Copyright &copy; AASRA 2016
                    </div>
                </div>
                <a href="https://www.facebook.com/profile.php?id=100008379319496">Designed by Sitesh Pattanaik</a>
            </div>
        </div>
</footer>