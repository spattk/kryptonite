<footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; 2016 <a href="#">AASRA</a>.</strong> All rights reserved.
    Website by <strong>Sitesh Pattanaik</strong>
</footer>