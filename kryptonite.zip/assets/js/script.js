$("ul.nav-tabs a").click(function (e) {
  e.preventDefault();  
    $(this).tab('show');
});

$("ul.nav-pills a").click(function (e) {
  e.preventDefault();  
    $(this).tab('show');
});

